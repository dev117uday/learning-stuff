/*
    Program Description program to base^power
    Function Name : gcd_of_two_numbers(int,int) -- return type int
  
*/

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    double base=0, power=0;
    cout << "Base = ";
    cin >> base;
    cout << "power = ";
    cin >> power ;
    cout << "Output : " << pow(base,power) << endl;  

}