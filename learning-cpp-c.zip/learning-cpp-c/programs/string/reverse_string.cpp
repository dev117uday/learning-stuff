/*
    Program Description program to find the gcd of two given number
*/

#include <bits/stdc++.h>

using namespace std;

int main()
{
    string input_string;
    cout << "input = ";
    getline(cin,input_string);
    reverse(input_string.begin(),input_string.end());
    cout << "reverse : " << input_string << endl;
}
