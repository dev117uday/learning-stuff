#include <iostream>

using namespace std;

int main(){

	int num = 0;
	cout << "Value of num : " << num << "\n";
	cout << "Address of num : " << &num << "\n";
	return 0;
	
}