def test(x):
    y = 0
    for i in range(x):
        y += i
    return y
