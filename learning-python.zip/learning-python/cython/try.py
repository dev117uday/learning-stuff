prime = [i for i in range(4+1)]
print(prime)
