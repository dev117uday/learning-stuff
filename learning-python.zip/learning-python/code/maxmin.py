list = [1,2,3,4,5]

print(max(list))
print()
print(min(list))