food = ['panner', 'curd', 'chole', 'rajma']

for foods in food[1:]:
    print(foods[:])
    print(len(foods))
'''
range example

for x in range(10):
    print(x+1)

print(food[0])
'''
var = 12
