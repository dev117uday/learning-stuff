def fish():
    print('i am a tuna fish')
    print('this is amazing, using nano editor, it\'s freaking awesome')
