class Init:

    def __init__(self):
        print('print from init')

    def swim(self):
        print('I am swimming ')


callx = Init()
callx.swim()
