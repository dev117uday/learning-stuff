income = [10, 30, 75]


def double_money(moneyx):
    return moneyx*2


print(int(map(double_money, income)))
