import math

#print(modf(110.72)) ## modf return two values in a tuple with first value being the the decimal 
# and second value being the integer,, thats why it cant be passed to round function
#print()
#print(round(modf(100.72,2)))