def answer(x): return x*7
sum = lambda a,b: a+b

print(answer(5))
print("Sum : " + str(sum(1,4)))