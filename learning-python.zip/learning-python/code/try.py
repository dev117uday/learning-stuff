if 3.21 > 3.2:
    print("true")
else :
    print("false")

# import random
# class person:
#     def __init__(self, hp, mp, atk, df, magic): 
#         self.maxhp=hp
#         self.hp=hp   
#         self.max=mp
#         self.atkl=atk-10
#         self.atkh=atk+10
#         self.df=df
#         self.magic=magic
#         self.action = ["Attack","magic"]

#     def generate_damage(self):
#         return random.randrange(self.atkl, self.atkh)    

# magic = [{"name": "fire", "cost": 10, "dmg": 60},
#         {"name": "thunder", "cost": 10, "dmg": 60},
#         {"name": "ice", "cost": 10, "dmg": 60}]
        
# player = person(500, 65, 70, 34, magic)
# print(player.generate_damage())
