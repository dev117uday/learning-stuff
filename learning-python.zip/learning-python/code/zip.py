first = ['uday', 'yash', 'kinshuk']
second = ['yadav', 'jain', 'guatum']

names = zip(first, second)

for a, b in names:
    print(a, b)


# print(names)
