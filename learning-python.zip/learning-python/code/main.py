import lib
import random

lib.fish()

x = random.randrange(1, 1000)
print(x)
