import os
os.mkdir("trydir")
os.chdir("trydir")
