class Human:
    gender = 'unknown'

    def __init__(self, name):
        self.name = name


h1 = Human('uday')
h2 = Human('duay')
