# Binary and

a = 50  # 110010
b = 25  # 011001

c = a & b

print(bin(c))
