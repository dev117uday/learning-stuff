fn main () {
	let f = 24.324;
	let i = f as u8;
	let c = i as char;
	println!("{} {} {}",f,i,c);
	println!("{}", 255 as char);
}