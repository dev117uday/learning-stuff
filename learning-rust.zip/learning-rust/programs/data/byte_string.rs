fn main(){

	// using the ascii representation of characters

	let method = b"GET";
	println!("{:?}",method);

}