mod lib;

fn main() {
    println!("Hello, world!");
    lib::eat_at_restaurant();
}

