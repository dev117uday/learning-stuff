fn main(){

	for x in 0..4 {
		println!("{}", x);
	}

}