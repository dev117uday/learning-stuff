// entry point of program
fn main(){
	println!("Hello World!");
}

