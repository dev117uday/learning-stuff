// this is single line comment

/*
this
is
multi
line
comment 
*/

fn main(){
	println!("Can you see comments ?");
	//they are everywhere
}