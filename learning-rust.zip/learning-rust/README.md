# Learning Rust programming language

Done with Rust Programming language for now.

##### File Extension : 
```rs
main.rs
```

##### Compile the code using :
```bash
rustc main.rs
```
this create a executable file

##### Run using 
```bash
./main
```

## Cargo
It is Rust's package manager

find more about Cargo [here](./readme/cargo_intro.md)