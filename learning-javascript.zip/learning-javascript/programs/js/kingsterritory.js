// kings problem
// try to comment the let king declaration

let king ='uday';

if (true)
{
    let king='sam';
    if (true)
    {
        let king ='ram';
        console.log(king);
    }
    console.log(king);
}
console.log(king)

if (true)
{
    console.log(king);
}
