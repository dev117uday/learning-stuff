if (false)
{
    console.log('inside the if statement');
}
else 
    console.log('inside the false block');

