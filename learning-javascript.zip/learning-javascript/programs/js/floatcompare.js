if (3.21 == 3.21) {
	console.log("Hello")
} else {
	console.log("false")
}

