
const cameras = {
    price: 600,
    weight: 2000,
    description: () => `this is canon ${this.price}$`,

}

console.log(cameras.description());