
for (let i = 0 ; i <= 30 ; i++)

console.log(Math.floor(Math.random()*6+1));
