//String type

var nameFirst = 'uday';
var nameLast = 'yadav';
const nameFull = nameFirst+" "+nameLast;
console.log(nameFull);

// Number type

var fah ;
console.log(fah);

