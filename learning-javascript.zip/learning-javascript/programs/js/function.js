function logpersonal(name)
{
    console.log(`printing from inside the ${name}`);
}

logpersonal('function');