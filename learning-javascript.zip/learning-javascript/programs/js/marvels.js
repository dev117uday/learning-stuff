// datatype - array

console.log('#####################');

const superheros = ['ironman','spiderman','marvel','thor'];


superheros.splice(1,2,'dr strange','antman');

console.log(superheros);

