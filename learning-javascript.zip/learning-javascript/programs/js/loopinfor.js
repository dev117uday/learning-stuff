
let name =[] ;


for (let index = 0; index < 10; index++) 
{    
    name.push(index);    
}

console.log(name);