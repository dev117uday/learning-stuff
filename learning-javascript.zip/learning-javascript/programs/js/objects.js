let myyoutube = 
{
    title: 'loop for in python',
    videolength: 15,
    viddiescription: 'come on who reads it',
    arr:['ironman','thor'],
    
}

console.log(myyoutube.title+', '+ myyoutube.viddiescription +", " + myyoutube.arr[0]+ " ?");