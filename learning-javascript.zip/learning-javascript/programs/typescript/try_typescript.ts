export { };
enum Color {
    Red,
    Green,
    Blue,
}

let c: Color = Color.Blue;
console.log(c);