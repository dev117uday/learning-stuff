# Learning Javascript

1. basic javascript
2. basic typescript
3. WD50
4. MongoDB
5. Javascript Design Pattern
6. basic npm package
7. scrapper

Directory Tree
```
.
├── learning_npm
│   ├── package.json
│   └── package-lock.json
├── programs
│   ├── js
│   │   ├── arrow.js
│   │   ├── arrowthis.js
│   │   ├── dice.js
│   │   ├── floatcompare.js
│   │   ├── function.js
│   │   ├── ifandelse.js
│   │   ├── kingsterritory.js
│   │   ├── loopinfor.js
│   │   ├── maps.js
│   │   ├── marvels.js
│   │   ├── objects.js
│   │   ├── startscript.js
│   │   ├── trello2.js
│   │   ├── trello3.js
│   │   ├── trello.js
│   │   ├── variable.js
│   │   └── webcheck.js
│   ├── typescript
│   │   ├── any.ts
│   │   └── try_typescript.ts
│   └── WD50
│       ├── counter1.html
│       ├── counter.js
│       ├── couter0.html
│       ├── hello1.html
│       ├── hello1.js
│       ├── hellocolor2.html
│       ├── hellocolor2.js
│       ├── hellocolor.html
│       └── hellocolor.js
├── README.md
└── scripts
    └── scrapper
        └── scrapper-google
            ├── index.js
            └── package.json

8 directories, 33 files

```
   

   

