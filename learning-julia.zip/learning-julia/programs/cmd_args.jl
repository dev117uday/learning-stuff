println(PROGRAM_FILE)
for x in ARGS
	println(x)
end
