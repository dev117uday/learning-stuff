# Learning Julia Programming Language

Julia is Awesome

    1.Steps to Work on this repo
    2.Install Julia
    3. Create a python virtualenv
    4.install jupyter notebook 
    5.launch Julia Terminal

Run the following code to install IJulia:
```
>using Pkg
>Pkg.add("IJulia")
```
that's it, open jupyter notebook, select Julia and you are good to go

Packages Used :
```
IJulia
PlotlyJS
Plots
Example
Colors
ORCA
```
