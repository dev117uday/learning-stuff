x=3;
if x>5,
  disp("x is larger than 5")
elseif x==3
  display("x is 3")
  break
  display("break called")
else
  disp("x is smaller")
 end;