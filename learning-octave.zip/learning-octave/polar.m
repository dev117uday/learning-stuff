x = 0:0.1:2*pi;
y = linspace(0.1,0.1,63)
polar(x,y)