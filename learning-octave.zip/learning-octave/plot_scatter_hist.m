#y = 0:20;
#a = y.^2;
#plot(a);
#scatter(y,a);
#
#b = randn(1000,1);
#hist(b)
#hist(b,30)

