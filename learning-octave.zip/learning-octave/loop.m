for i=1:10;
  display(sprintf("%ith is the number",i))
end;
i=1;
while i<4,
  display(i);
  i=i+1;
end;