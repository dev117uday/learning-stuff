x = [1 2 3 2 1];
y = x;
z = x' * y;
z
axis([1 5 1 5]);
contour(z)