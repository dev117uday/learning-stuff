a = rand(6,6)
save mydata.dat a
loadz = load("mydata.dat")
loadz
