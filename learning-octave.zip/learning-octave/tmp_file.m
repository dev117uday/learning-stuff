rdx = rand(6,6)
tmpx = tmpfile
save tmpx rdx
load tmpx
rdx