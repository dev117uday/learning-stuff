a = rand(2,1)
b = rand(2,1)
c = [a b]
d = [a,b]